#pragma once

bool is_dir_exist(const char *s);
pid_t popen2(char **command, int *infp, int *outfp);
